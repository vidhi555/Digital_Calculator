﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Calculator_new
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        static string num1 = " ";
        static string num2 = " ";
        static string op;
        static bool isOperator = false;

        protected void Page_Load(object sender, EventArgs e)
        {
            txtcal.Text = "    0";
        }
        protected void display()
        {
            txtcal.Text = "   "+ num1 + " " + op + " " + num2;
        }

        protected void btnAc_Click(object sender, EventArgs e)
        {
            txtcal.Text = "    0";
            op = "";
            num1 = "";
            num2 = "";
            isOperator = false;
        }

        protected void btn7_Click(object sender, EventArgs e)
        {
            if (isOperator == false)
            {
                num1 += "7";
            }
            else
            {
                num2 += "7";
            }
            display();
        }

        protected void btn8_Click(object sender, EventArgs e)
        {
            if (isOperator == false)
            {
                num1 += "8";
            }
            else
            {
                num2 += "8";
            }
            display();
        }

        protected void btn9_Click(object sender, EventArgs e)
        {
            if (isOperator == false)
            {
                num1 += "9";
            }
            else
            {
                num2 += "9";
            }
            display();
        }

        protected void btn4_Click(object sender, EventArgs e)
        {
            if (isOperator == false)
            {
                num1 += "4";
            }
            else
            {
                num2 += "4";
            }
            display();
        }

        protected void btn5_Click(object sender, EventArgs e)
        {
            if (isOperator == false)
            {
                num1 += "5";
            }
            else
            {
                num2 += "5";
            }
            display();
        }

        protected void btn6_Click(object sender, EventArgs e)
        {
            if (isOperator == false)
            {
                num1 += "6";
            }
            else
            {
                num2 += "6";
            }
            display();
        }

        protected void btn1_Click(object sender, EventArgs e)
        {
            if (isOperator == false)
            {
                num1 += "1";
            }
            else
            {
                num2 += "1";
            }
            display();
        }

        protected void btn2_Click(object sender, EventArgs e)
        {
            if (isOperator == false)
            {
                num1 += "2";
            }
            else
            {
                num2 += "2";
            }
            display();
        }

        protected void btn3_Click(object sender, EventArgs e)
        {
            if (isOperator == false)
            {
                num1 += "3";
            }
            else
            {
                num2 += "3";
            }
            display();
        }
        
        protected void btnplus_Click(object sender, EventArgs e)
        {
            if (!isOperator && num1 != " ")
            {
                op += "+";
                isOperator = true;
                display();
            }
            
        }

        protected void btnDivide_Click(object sender, EventArgs e)
        {
            if (!isOperator)
            {
                op += "/";
                isOperator = true;
                display();
            }
            
        }

        protected void btnmultiply_Click(object sender, EventArgs e)
        {
            if (!isOperator)
            {
                op += "*";
                isOperator = true;
                display();
            }
            
        }

        protected void btnMinus_Click(object sender, EventArgs e)
        {
            if (!isOperator)
            {
                op += "-";
                isOperator = true;
                display();
            }
            
        }

        protected void btn1equal_Click(object sender, EventArgs e)
        {
            try
            {
                double n1 = Convert.ToDouble(num1);
                double n2 = Convert.ToDouble(num2);
                double res = 0;

                if (string.IsNullOrEmpty(num1) || string.IsNullOrEmpty(num2))
                {
                    txtcal.Text = "Please enter valid numbers.";
                    return;
                }
                switch (op)
                {
                    case "+":
                        res = n1 + n2;
                        break;
                    case "-":
                        res = n1 - n2;
                        break;
                    case "*":
                        res = n1 * n2;
                        break;
                    case "%":
                        if (n2 == 0)
                        {
                            txtcal.Text = "Can not divide by zero!";
                            return;
                        }
                        else
                        {
                            res = n1 % n2;
                        }
                        break;
                    case "/":
                        if (n2 == 0)
                        {
                            txtcal.Text = "Can not divide by zero!";
                            return;
                        }
                        else
                        {
                            res = n1 / n2;
                        }
                        break;

                }

                txtcal.Text = "   " + num1 + " " + op + " " + num2 + "  =  " + res.ToString();
                num1 = res.ToString();
                num2 = "";
                op = "";
                isOperator = false;
            }
            catch (Exception ex)
            {
                txtcal.Text = "Error: " + ex.ToString();
            }
            
        }

      

        protected void btn0_Click(object sender, EventArgs e)
        {
            if (isOperator == false)
            {
                num1 += "0";
            }
            else
            {
                num2 += "0";
            }
            display();
        }

        protected void btnC_Click(object sender, EventArgs e)
        {
            if (!isOperator)
            {
                if (!string.IsNullOrEmpty(num1))
                {
                    num1 = num1.Remove(num1.Length - 1);
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(num2))
                {
                    num2 = num2.Substring(0, num2.Length - 1);
                }
                else if (!string.IsNullOrEmpty(op))
                {
                    op = "";
                    isOperator = false;
                }
            }
            
            
            display();

        }

        protected void btnmodulo_Click(object sender, EventArgs e)
        {
            if (!isOperator)
            {
                op += "%";
                isOperator = true;
                display();
            }
        }

        protected void btn00_Click(object sender, EventArgs e)
        {
            if (!isOperator)
            {
                num1 += "00";
            }
            else
            {
                num2 += "00";
            }
            display();
        }

        protected void btndot_Click(object sender, EventArgs e)
        {
            if (!isOperator)
            {
                num1 += ".";
            }
            else
            {
                num2 += ".";
            }
            display();
        }
    }
}